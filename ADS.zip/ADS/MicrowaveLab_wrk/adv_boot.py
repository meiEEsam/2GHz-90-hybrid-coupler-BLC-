# -*- coding: utf-8 -*-

import empro.toolkit.adv as adv

def main():
	path=r"E:/sources/Eectromagnetics/ADS_simlation/MicrowaveLab_wrk"
	lib=r"MicrowaveLab_lib"
	subst=r"MicrowaveLab_lib/substrate1.subst"
	substlib=r"MicrowaveLab_lib"
	substname=r"substrate1"
	cell=r"cell_3"
	view=r"layout"
	libS3D=r"simulation/%Microwave%Lab_lib/cell_3/_3%D%Viewer/proj_libS3D.xml"
	varDictionary={}
	exprDictionary={}
	hpeesof_dir=r"C:\Program Files\Keysight\ADS2017"

	adv.loadDesign(path=path, lib=lib, subst=subst, substlib=substlib, substname=substname, cell=cell, view=view, libS3D=libS3D, var_dict=varDictionary, expr_dict=exprDictionary, hpeesof_dir=hpeesof_dir)
